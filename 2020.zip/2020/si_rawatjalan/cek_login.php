<?php 
include "config/koneksi.php";
function anti_injection($data){
  $filter = mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
  return $filter;
}

$username = anti_injection($_POST['username']);
$pass     = anti_injection(md5($_POST['password']));

// pastikan username dan password adalah berupa huruf atau angka.
if (!ctype_alnum($username) OR !ctype_alnum($pass)){
  echo"<script>alert('Maaf anda bukan user atau admin'); window.location = 'logout.php'</script> ";
}
else{
$login=mysql_query("SELECT * FROM users WHERE username='$_POST[username]' AND password='$pass' ");
$ketemu=mysql_num_rows($login);
$r=mysql_fetch_array($login);
// Apabila username dan password ditemukan
if ($ketemu > 0){
  session_start();
  include"timeout.php";
  
  session_register("namauser");
  session_register("passuser");
  session_register("leveluser");
  session_register("namalengkap");

  $_SESSION[namauser]     = $r[username];
  $_SESSION[passuser]     = $r[password];
  $_SESSION[leveluser]    = $r[level];
  $_SESSION[id]			  = $r[id_admin];
  $_SESSION[namalengkap]  = $r[nama_lengkap];
	
	setcookie("username", "$r[username]", time()+3600);
  
   header('location:media.php?module=home');
}
else{
  echo "<link href=css/style.css rel=stylesheet type=text/css>";
  echo "<center>LOGIN GAGAL! <br> 
        Username atau Password Anda tidak benar.<br>
        Atau account Anda sedang diblokir.<br>";
  echo "<a href=index.php><b>ULANGI LAGI</b></a></center>";
}
}

?>
