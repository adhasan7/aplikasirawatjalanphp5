<?php
session_start();
include "../../config/koneksi.php";
include "../../config/fungsi_seo.php";

$module=$_GET[module];
$act=$_GET[act];
$ss=$_GET[ss];
$tt=$_GET[tt];
$resep=$_POST[resep];


if ($_POST[keterangan_obat]==''){
$keterangan=$resep;
}else{
$keterangan=$_POST[keterangan_obat].' , '.$resep;
}

//echo "id = ". $_POST[id] . " module = " . $module . " act = " . $act . " ss = " . $ss . " tt = " . $tt . " keterangan = " . $keterangan . " resep = " . $resep;

// Update pemeriksaan
if ($module=='pemeriksaan' AND $act=='update'){
  mysql_query("UPDATE pendaftaran SET id_dokter = '$_POST[id_dokter]',
  diagnosa = '$_POST[diagnosa]',
  keterangan_obat = '$keterangan',
  keterangan_khusus = '$_POST[keterangan_khusus]',
  status = '$_POST[status]'
  WHERE id_pendaftaran= '$_POST[id]'");

  //echo "id = ". $_POST[id] . " diagnosa = " . $_POST[diagnosa] . " keterangan_obat = " . $keterangan . " keterangan_khusus = " . $_POST[keterangan_khusus] . " status = " . $_POST[status];

  if ($_POST[status]=='Periksa') {
    $tampil=mysql_query("SELECT * FROM detail_resep A, obat B where A.id_obat=B.id_obat AND A.id_resep='$_POST[id]'");
    while ($r=mysql_fetch_array($tampil)){
    $jml=$r[qty]*$r[harga];
    $ttl+=$jml;
    }
    mysql_query("INSERT INTO resep(id_resep,id_pendaftaran,jumlah) VALUES('$_POST[id]','$_POST[id]',$ttl)");
    header('location:../../media.php?module='.$module);
  }else{
  header('location:../../media.php?module='.$module.'&act='.$ss.'&id='.$tt);
  }
}
// Input resep obat
elseif ($module=='pemeriksaan' AND $act=='inputobat'){
  mysql_query("INSERT INTO detail_resep(id_resep,id_obat,qty,harga) VALUES('$_POST[id]','$_POST[id_obat]','$_POST[qty]','$_POST[harga]')");
  header('location:../../media.php?module='.$module.'&act='.$ss.'&id='.$tt);
}
// Input resep obat
elseif ($module=='pemeriksaan' AND $act=='cariobat'){
  //echo "id = ". $_POST[id] . " obat = " . $_POST[id_obat] . " qty = " . $_POST[qty] . " harga = " . $_POST[harga];
  header('location:../../media.php?module='.$module.'&act='.$ss.'&id='.$tt.'&idobat='.$_POST[id_obat]);
}
?>
