<?php
include "config/library.php";
include "config/koneksi.php";
include "config/tanggal.php"; 
error_reporting(E_ALL & ~E_NOTICE);
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<title>BALAI PENGOBATAN NIRMALA</title>
<link href="default.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="stylesheets/login.css" type="text/css" media="screen" title="no title" />
</head>
<body>
<div id="header">
	<div id="topmenu">     	
	<pre><font color="#FFFFFF" size="+2">BALAI PENGOBATAN NIRMALA
</font>SISTEM INFORMASI MANAJEMEN RAWAT JALAN</pre>
  </div>
</div>
<div id="menu">
	<ul>
		<li class="first"><a href="index.php">Home</a></li>
		<li><a href="sejarah.php">Sejarah</a></li>
		<li><a href="daftar_guru.php">Data Dokter</a></li>
		<li><a href="login.php">Login</a></li>
		
		
	</ul>
</div>
<div id="content">
  <div id="imain">
		<p>&nbsp;</p>
		<p>
		fdsadhhdjsasd
    </p>
  </div>
  
</div>
<div id="footer">
	<p id="legal">CopyRight@2020 Sistem Informasi Manajemen Pasien Rawat Jalan<br />
	  Desain By Agus dan Hasan
</p>
	<p id="links"><a href="#"><a href="#"></a></p>
</div>
</body>
</html>
