<?php
function radio1($value){
if($value=='Islam'){
?>
						<label>Agama</label>
						<input type="radio" name="agama" id="rd-1" value="Islam" checked="checked" /> 
						<label for="rd-1">Islam</label><br />
						<input type="radio" name="agama" id="rd-2" value="Kristen Katolik" /> 
						<label for="rd-2">Kristen Katolik </label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-3" value="Kristen Protestan" /> 
						<label for="rd-3">Kristen protestan</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-4" value="Hindu" /> 
						<label for="rd-4">Hindu</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-5" value="Budha" /> 
						<label for="rd-5">Budha</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-6" value="Khonghucu" /> 
						<label for="rd-6">Khonghucu</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-7" value="Aliran Kepercayaan" /> 
						<label for="rd-7">Aliran Kepercayaan</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-8" value="sejene" /> 
						<label for="rd-8">Agama lainnya</label><input type="text" class="small" name="agama_add" style="margin-left:-30px;" /><br />

<?php
}elseif($value=='Kristen Katolik'){
?>
						<label>Agama</label>
						<input type="radio" name="agama" id="rd-1" value="Islam" /> 
						<label for="rd-1">Islam</label><br />
						<input type="radio" name="agama" id="rd-2" value="Kristen Katolik" checked="checked" /> 
						<label for="rd-2">Kristen Katolik</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-3" value="Kristen Protestan" /> 
						<label for="rd-3">Kristen protestan</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-4" value="Hindu" /> 
						<label for="rd-4">Hindu</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-5" value="Budha" /> 
						<label for="rd-5">Budha</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-6" value="Khonghucu" /> 
						<label for="rd-6">Khonghucu</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-7" value="Aliran Kepercayaan" /> 
						<label for="rd-7">Aliran Kepercayaan</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-8" value="sejene" /> 
						<label for="rd-8">Agama lainnya</label><input type="text" class="small" name="agama_add" style="margin-left:-30px;" /><br />

<?php
}elseif($value=='Kristen Protestan'){
?>
						<label>Agama</label>
						<input type="radio" name="agama" id="rd-1" value="Islam" /> 
						<label for="rd-1">Islam</label><br />
						<input type="radio" name="agama" id="rd-2" value="Kristen Katolik" /> 
						<label for="rd-2">Kristen Katolik</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-3" value="Kristen Protestan" checked="checked" /> 
						<label for="rd-3">Kristen protestan</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-4" value="Hindu" /> 
						<label for="rd-4">Hindu</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-5" value="Budha" /> 
						<label for="rd-5">Budha</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-6" value="Khonghucu" /> 
						<label for="rd-6">Khonghucu</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-7" value="Aliran Kepercayaan" /> 
						<label for="rd-7">Aliran Kepercayaan</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-8" value="sejene" /> 
						<label for="rd-8">Agama lainnya</label><input type="text" class="small" name="agama_add" style="margin-left:-30px;" /><br />

<?php
}elseif($value=='Hindu'){
?>
						<label>Agama</label>
						<input type="radio" name="agama" id="rd-1" value="Islam" /> 
						<label for="rd-1">Islam</label><br />
						<input type="radio" name="agama" id="rd-2" value="Kristen Katolik" /> 
						<label for="rd-2">Kristen Katolik</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-3" value="Kristen Protestan" /> 
						<label for="rd-3">Kristen protestan</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-4" value="Hindu" checked="checked" /> 
						<label for="rd-4">Hindu</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-5" value="Budha" /> 
						<label for="rd-5">Budha</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-6" value="Khonghucu" /> 
						<label for="rd-6">Khonghucu</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-7" value="Aliran Kepercayaan" /> 
						<label for="rd-7">Aliran Kepercayaan</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-8" value="sejene" /> 
						<label for="rd-8">Agama lainnya</label><input type="text" class="small" name="agama_add" style="margin-left:-30px;" /><br />

<?php
}elseif($value=='Budha'){
?>
						<label>Agama</label>
						<input type="radio" name="agama" id="rd-1" value="Islam" /> 
						<label for="rd-1">Islam</label><br />
						<input type="radio" name="agama" id="rd-2" value="Kristen Katolik" /> 
						<label for="rd-2">Kristen Katolik</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-3" value="Kristen Protestan" /> 
						<label for="rd-3">Kristen protestan</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-4" value="Hindu" /> 
						<label for="rd-4">Hindu</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-5" value="Budha" checked="checked" /> 
						<label for="rd-5">Budha</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-6" value="Khonghucu" /> 
						<label for="rd-6">Khonghucu</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-7" value="Aliran Kepercayaan" /> 
						<label for="rd-7">Aliran Kepercayaan</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-8" value="sejene" /> 
						<label for="rd-8">Agama lainnya</label><input type="text" class="small" name="agama_add" style="margin-left:-30px;" /><br />

<?php
}elseif($value=='Konghucu'){
?>
						<label>Agama</label>
						<input type="radio" name="agama" id="rd-1" value="Islam" /> 
						<label for="rd-1">Islam</label><br />
						<input type="radio" name="agama" id="rd-2" value="Kristen Katolik" /> 
						<label for="rd-2">Kristen Katolik</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-3" value="Kristen Protestan" /> 
						<label for="rd-3">Kristen protestan</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-4" value="Hindu" /> 
						<label for="rd-4">Hindu</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-5" value="Budha" /> 
						<label for="rd-5">Budha</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-6" value="Khonghucu" checked="checked" /> 
						<label for="rd-6">Khonghucu</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-7" value="Aliran Kepercayaan" /> 
						<label for="rd-7">Aliran Kepercayaan</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-8" value="sejene" /> 
						<label for="rd-8">Agama lainnya</label><input type="text" class="small" name="agama_add" style="margin-left:-30px;" /><br />

<?php
}elseif($value=='Aliran Kepercayaan'){
?>
						<label>Agama</label>
						<input type="radio" name="agama" id="rd-1" value="Islam" /> 
						<label for="rd-1">Islam</label><br />
						<input type="radio" name="agama" id="rd-2" value="Kristen Katolik" /> 
						<label for="rd-2">Kristen Katolik</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-3" value="Kristen Protestan" /> 
						<label for="rd-3">Kristen protestan</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-4" value="Hindu" /> 
						<label for="rd-4">Hindu</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-5" value="Budha" /> 
						<label for="rd-5">Budha</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-6" value="Khonghucu" /> 
						<label for="rd-6">Khonghucu</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-7" value="Aliran Kepercayaan" checked="checked" /> 
						<label for="rd-7">Aliran Kepercayaan</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-8" value="sejene" /> 
						<label for="rd-8">Agama lainnya</label><input type="text" class="small" name="agama_add" style="margin-left:-30px;" /><br />

<?php
}else{
?>
						<label>Agama</label>
						<input type="radio" name="agama" id="rd-1" value="Islam" /> 
						<label for="rd-1">Islam</label><br />
						<input type="radio" name="agama" id="rd-2" value="Kristen Katolik" /> 
						<label for="rd-2">Kristen Katolik</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-3" value="Kristen Protestan" /> 
						<label for="rd-3">Kristen protestan</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-4" value="Hindu" /> 
						<label for="rd-4">Hindu</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-5" value="Budha" /> 
						<label for="rd-5">Budha</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-6" value="Khonghucu" /> 
						<label for="rd-6">Khonghucu</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-7" value="Aliran Kepercayaan" /> 
						<label for="rd-7">Aliran Kepercayaan</label><br />
						<label></label>
                        <input type="radio" name="agama" id="rd-8" value="sejene" checked="checked" /> 
						<label for="rd-8">Agama lainnya</label><input type="text" class="small" name="agama_add" value="<?php echo"$value"; ?>" style="margin-left:-30px;" /><br />

<?php
}
}


function radio2($value){
if($value=='L'){
?>
						<label>Jenis Kelamin</label>
						<input type="radio" name="jenis_kelamin" id="rdo-1" value="L" checked="checked" /> 
						<label for="rdo-1">Laki-laki</label>
						<input type="radio" name="jenis_kelamin" id="rdo-2" value="P" /> 
						<label for="rdo-2">Perempuan</label><br />
<?php
}else{
?>
						<label>Jenis Kelamin</label>
						<input type="radio" name="jenis_kelamin" id="rdo-1" value="L" /> 
						<label for="rdo-1">Laki-laki</label>
						<input type="radio" name="jenis_kelamin" id="rdo-2" value="P" checked="checked" /> 
						<label for="rdo-2">Perempuan</label><br />
<?php
}
}


function radio3($value){
if($value=='Belum Menikah'){
?>
						<label>Status</label>
						<input type="radio" name="status_kawin" id="r-1" value="Belum Menikah" checked="checked" /> 
						<label for="r-1">Belum Menikah</label>
						<input type="radio" name="status_kawin" id="r-2" value="Menikah" /> 
						<label for="r-2">Menikah</label><br />
<?php
}else{
?>
						<label>Status</label>
						<input type="radio" name="status_kawin" id="r-1" value="Belum Menikah" /> 
						<label for="r-1">Belum Menikah</label>
						<input type="radio" name="status_kawin" id="r-2" value="Menikah" checked="checked" /> 
						<label for="r-2">Menikah</label><br />
<?php
}
}


function radio4($value){
if($value=='ABRI'){
?>
						<label>Pekerjaan Orang Tua</label>
						<input type="radio" name="pekerjaan_ortu" id="rad-1" value="ABRI" checked="checked" /> 
						<label for="rad-1">ABRI</label><br />
						<input type="radio" name="pekerjaan_ortu" id="rad-2" value="P.Swasta" /> 
						<label for="rad-2">P.Swasta</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-3" value="PNS" /> 
						<label for="rad-3">PNS</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-4" value="BUMN" /> 
						<label for="rad-4">BUMN</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-5" value="Petani"/> 
						<label for="rad-5">Petani</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-6" value="Nelayan"/> 
						<label for="rad-6">Nelayan</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-7" value="sanese" /> 
						<label for="rad-7">Pekerjaan lainnya</label><input type="text" class="small" name="pekerjaan_add" style="margin-left:-30px"/><br />
<?php
}elseif($value=='P.Swasta'){
?>
						<label>Pekerjaan Orang Tua</label>
						<input type="radio" name="pekerjaan_ortu" id="rad-1" value="ABRI" /> 
						<label for="rad-1">ABRI</label><br />
						<input type="radio" name="pekerjaan_ortu" id="rad-2" value="P.Swasta" checked="checked" /> 
						<label for="rad-2">P.Swasta</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-3" value="PNS" /> 
						<label for="rad-3">PNS</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-4" value="BUMN" /> 
						<label for="rad-4">BUMN</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-5" value="Petani"/> 
						<label for="rad-5">Petani</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-6" value="Nelayan"/> 
						<label for="rad-6">Nelayan</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-7" value="sanese" /> 
						<label for="rad-7">Pekerjaan lainnya</label><input type="text" class="small" name="pekerjaan_add" style="margin-left:-30px"/><br />
<?php
}elseif($value=='PNS'){
?>
						<label>Pekerjaan Orang Tua</label>
						<input type="radio" name="pekerjaan_ortu" id="rad-1" value="ABRI" /> 
						<label for="rad-1">ABRI</label><br />
						<input type="radio" name="pekerjaan_ortu" id="rad-2" value="P.Swasta" /> 
						<label for="rad-2">P.Swasta</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-3" value="PNS" checked="checked" /> 
						<label for="rad-3">PNS</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-4" value="BUMN" /> 
						<label for="rad-4">BUMN</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-5" value="Petani"/> 
						<label for="rad-5">Petani</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-6" value="Nelayan"/> 
						<label for="rad-6">Nelayan</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-7" value="sanese" /> 
						<label for="rad-7">Pekerjaan lainnya</label><input type="text" class="small" name="pekerjaan_add" style="margin-left:-30px"/><br />
<?php
}elseif($value=='BUMN'){
?>
						<label>Pekerjaan Orang Tua</label>
						<input type="radio" name="pekerjaan_ortu" id="rad-1" value="ABRI" /> 
						<label for="rad-1">ABRI</label><br />
						<input type="radio" name="pekerjaan_ortu" id="rad-2" value="P.Swasta" /> 
						<label for="rad-2">P.Swasta</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-3" value="PNS" /> 
						<label for="rad-3">PNS</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-4" value="BUMN" checked="checked" /> 
						<label for="rad-4">BUMN</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-5" value="Petani"/> 
						<label for="rad-5">Petani</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-6" value="Nelayan"/> 
						<label for="rad-6">Nelayan</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-7" value="sanese" /> 
						<label for="rad-7">Pekerjaan lainnya</label><input type="text" class="small" name="pekerjaan_add" style="margin-left:-30px"/><br />
<?php
}elseif($value=='Petani'){
?>
						<label>Pekerjaan Orang Tua</label>
						<input type="radio" name="pekerjaan_ortu" id="rad-1" value="ABRI" /> 
						<label for="rad-1">ABRI</label><br />
						<input type="radio" name="pekerjaan_ortu" id="rad-2" value="P.Swasta" /> 
						<label for="rad-2">P.Swasta</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-3" value="PNS" /> 
						<label for="rad-3">PNS</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-4" value="BUMN" /> 
						<label for="rad-4">BUMN</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-5" value="Petani" checked="checked" /> 
						<label for="rad-5">Petani</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-6" value="Nelayan"/> 
						<label for="rad-6">Nelayan</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-7" value="sanese" /> 
						<label for="rad-7">Pekerjaan lainnya</label><input type="text" class="small" name="pekerjaan_add" style="margin-left:-30px"/><br />
<?php
}elseif($value=='Nelayan'){
?>
						<label>Pekerjaan Orang Tua</label>
						<input type="radio" name="pekerjaan_ortu" id="rad-1" value="ABRI" /> 
						<label for="rad-1">ABRI</label><br />
						<input type="radio" name="pekerjaan_ortu" id="rad-2" value="P.Swasta" /> 
						<label for="rad-2">P.Swasta</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-3" value="PNS" /> 
						<label for="rad-3">PNS</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-4" value="BUMN" /> 
						<label for="rad-4">BUMN</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-5" value="Petani" /> 
						<label for="rad-5">Petani</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-6" value="Nelayan" checked="checked" /> 
						<label for="rad-6">Nelayan</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-7" value="sanese" /> 
						<label for="rad-7">Pekerjaan lainnya</label><input type="text" class="small" name="pekerjaan_add" style="margin-left:-30px"/><br />
<?php
}else{
?>
						<label>Pekerjaan Orang Tua</label>
						<input type="radio" name="pekerjaan_ortu" id="rad-1" value="ABRI" /> 
						<label for="rad-1">ABRI</label><br />
						<input type="radio" name="pekerjaan_ortu" id="rad-2" value="P.Swasta" /> 
						<label for="rad-2">P.Swasta</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-3" value="PNS" /> 
						<label for="rad-3">PNS</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-4" value="BUMN" /> 
						<label for="rad-4">BUMN</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-5" value="Petani" /> 
						<label for="rad-5">Petani</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-6" value="Nelayan" /> 
						<label for="rad-6">Nelayan</label><br />
						<label></label>
                        <input type="radio" name="pekerjaan_ortu" id="rad-7" value="sanese" checked="checked" /> 
						<label for="rad-7">Pekerjaan lainnya</label><input type="text" class="small" name="pekerjaan_add" value="<?php echo"$value"; ?>" style="margin-left:-30px"/><br />
<?php
}
}

function radio5($value){
if($value==0){
?>
						<label>Pilihan Kelas</label>
						<input type="radio" name="pilih_kelas" id="radios-1" value="0" checked="checked" /> 
						<label for="radios-1">REGULER (Pagi)</label><br />
						<input type="radio" name="pilih_kelas" id="radios-2" value="1" /> 
						<label for="radios-2">NON REGULER(Sore)</label><br />
<?php
}else{
?>
						<label>Pilihan Kelas</label>
						<input type="radio" name="pilih_kelas" id="radios-1" value="0" /> 
						<label for="radios-1">REGULER (Pagi)</label><br />
						<input type="radio" name="pilih_kelas" id="radios-2" value="1" checked="checked"/> 
						<label for="radios-2">NON REGULER(Sore)</label><br />
<?php
}
}

function radio6($value){
if($value==0){
?>
						<label>&nbsp;</label>
						<input type="radio" name="status_reg" id="radiose-1" value="0" checked="checked" /> 
						<label for="radiose-1">Belum Registrasi</label><br />
						<input type="radio" name="status_reg" id="radiose-2" value="1" /> 
						<label for="radiose-2">Sudah Registrasi</label><br />
<?php
}else{
?>
						<label>&nbsp;</label>
						<input type="radio" name="status_reg" id="radiose-1" value="0" /> 
						<label for="radiose-1">Belum Registrasi</label><br />
						<input type="radio" name="status_reg" id="radiose-2" value="1" checked="checked" /> 
						<label for="radiose-2">Sudah Registrasi</label><br />
<?php
}
}
?>