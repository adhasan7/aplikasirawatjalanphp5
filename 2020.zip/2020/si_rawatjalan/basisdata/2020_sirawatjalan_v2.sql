-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Waktu pembuatan: 12. Nopember 2020 jam 18:39
-- Versi Server: 5.5.16
-- Versi PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `2020_sirawatjalan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_pembayaran`
--

CREATE TABLE IF NOT EXISTS `detail_pembayaran` (
  `id_pembayaran` int(3) NOT NULL,
  `id_obat` int(3) NOT NULL,
  `qty` int(3) NOT NULL,
  `harga` int(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `detail_pembayaran`
--

INSERT INTO `detail_pembayaran` (`id_pembayaran`, `id_obat`, `qty`, `harga`) VALUES
(3, 14, 2, 4000),
(3, 16, 5, 4000),
(2, 14, 10, 4000),
(1, 15, 4, 2000),
(1, 14, 5, 4000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `dokter`
--

CREATE TABLE IF NOT EXISTS `dokter` (
  `id_dokter` int(11) NOT NULL AUTO_INCREMENT,
  `kode_dokter` varchar(20) NOT NULL,
  `nama_dokter` varchar(50) NOT NULL,
  `alamat_dokter` text NOT NULL,
  `tlp_dokter` varchar(20) NOT NULL,
  PRIMARY KEY (`id_dokter`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data untuk tabel `dokter`
--

INSERT INTO `dokter` (`id_dokter`, `kode_dokter`, `nama_dokter`, `alamat_dokter`, `tlp_dokter`) VALUES
(2, 'DR999', 'DR. M Suhendar', 'Cirebon', '08977665544');

-- --------------------------------------------------------

--
-- Struktur dari tabel `obat`
--

CREATE TABLE IF NOT EXISTS `obat` (
  `id_obat` int(10) NOT NULL AUTO_INCREMENT,
  `kode_obat` varchar(10) NOT NULL,
  `nama_obat` varchar(30) NOT NULL,
  `jenis_obat` varchar(20) NOT NULL,
  `harga` int(11) NOT NULL,
  `bentuk_obat` varchar(30) NOT NULL,
  PRIMARY KEY (`id_obat`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data untuk tabel `obat`
--

INSERT INTO `obat` (`id_obat`, `kode_obat`, `nama_obat`, `jenis_obat`, `harga`, `bentuk_obat`) VALUES
(16, 'AB003', 'Diabet', 'Probiotik', 4000, ''),
(15, 'AB002', 'Oskadon', 'Probiotik', 2000, ''),
(14, 'AB001', 'Promagh Hijau', 'Antibiotik', 4000, ''),
(17, 'Bg23723', 'Okere', 'Generik', 7000, 'Kaplet');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pasien`
--

CREATE TABLE IF NOT EXISTS `pasien` (
  `id_pasien` int(11) NOT NULL AUTO_INCREMENT,
  `nik_pasien` varchar(10) NOT NULL,
  `nama_pasien` varchar(50) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `alamat_pasien` text NOT NULL,
  `desa` varchar(150) NOT NULL,
  `tlp_pasien` varchar(20) NOT NULL,
  `pekerjaan` varchar(50) NOT NULL,
  `agama` varchar(30) NOT NULL,
  `status_pernikahan` varchar(30) NOT NULL,
  `kebangsaan` varchar(30) NOT NULL,
  `keluarga_lain` varchar(50) NOT NULL,
  `tlp_lain` varchar(20) NOT NULL,
  `alamat_lain` text NOT NULL,
  `hubungan_lain` varchar(30) NOT NULL,
  `no_rm` varchar(30) NOT NULL,
  `kode_pasien` varchar(20) NOT NULL,
  PRIMARY KEY (`id_pasien`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data untuk tabel `pasien`
--

INSERT INTO `pasien` (`id_pasien`, `nik_pasien`, `nama_pasien`, `tgl_lahir`, `alamat_pasien`, `desa`, `tlp_pasien`, `pekerjaan`, `agama`, `status_pernikahan`, `kebangsaan`, `keluarga_lain`, `tlp_lain`, `alamat_lain`, `hubungan_lain`, `no_rm`, `kode_pasien`) VALUES
(2, '3273728312', 'Wawan Kusnawan', '2015-10-14', 'Cirebon', 'Harjamukti', '089777721211', 'Swasta', 'Islam', 'Belum Kawin', 'WNI', 'Tati Nurhayati', '089998777777', 'Cirebon', 'Orang Tua', '232432132', 'PS001'),
(3, '12345', 'Jaya Kusuma', '2020-10-28', 'Cirebon', 'Harjamukti', '0897887666', 'Swasta', 'Islam', 'Belum Kawin', 'WNI', 'OKi', '08978888887', 'Cirebon', 'Orang Tua', '3432432432', 'PS002');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembayaran`
--

CREATE TABLE IF NOT EXISTS `pembayaran` (
  `id_pembayaran` int(3) NOT NULL,
  `id_pendaftaran` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `biaya_daftar` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pembayaran`
--

INSERT INTO `pembayaran` (`id_pembayaran`, `id_pendaftaran`, `jumlah`, `biaya_daftar`) VALUES
(1, 1, 28000, 50000),
(2, 2, 40000, 20000),
(3, 2, 28000, 10000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pendaftaran`
--

CREATE TABLE IF NOT EXISTS `pendaftaran` (
  `id_pendaftaran` int(3) NOT NULL AUTO_INCREMENT,
  `no_pendaftaran` varchar(40) NOT NULL,
  `tgl_daftar` date NOT NULL,
  `id_pasien` int(11) NOT NULL,
  `id_dokter` int(11) NOT NULL,
  `gejala` text NOT NULL,
  `diagnosa` text NOT NULL,
  `keterangan_obat` text NOT NULL,
  `keterangan_khusus` text NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`id_pendaftaran`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data untuk tabel `pendaftaran`
--

INSERT INTO `pendaftaran` (`id_pendaftaran`, `no_pendaftaran`, `tgl_daftar`, `id_pasien`, `id_dokter`, `gejala`, `diagnosa`, `keterangan_obat`, `keterangan_khusus`, `status`) VALUES
(1, 'ANTRIAN-01/28-10-2020', '2020-10-28', 2, 2, 'Batuk, Pilek dan Sakit Tenggorokan', 'Covid-19', 'Oskadon 2x1, Diapet 3x1', 'Jangan Makan Nasi', 'Selesai'),
(2, 'ANTRIAN-01/29-10-2020', '2020-10-29', 2, 2, 'Batuk dan Flu', 'Covid-19', 'Vaksin', 'Isolasi Mandiri', 'Selesai'),
(4, 'ANTRIAN-01/30-10-2020', '2020-10-30', 3, 2, 'Batuk dan Flu', '', 'Diabet , Promagh Hijau , Oskadon , ', 'Semangat', 'Selesai');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `username` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `password` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `nama_lengkap` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `no_telp` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `level` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT 'user',
  `blokir` enum('Y','N') COLLATE latin1_general_ci NOT NULL DEFAULT 'N',
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`username`, `password`, `nama_lengkap`, `email`, `no_telp`, `level`, `blokir`) VALUES
('agus', 'fdf169558242ee051cca1479770ebac3', 'Agus & Hasan', 'admin@administration.com', '0######', 'admin', 'N'),
('DR999', 'fa8f159e4b1c755a61e213154c05bb0c', 'DR. M Suhendar', 'kosong', '08977665544', 'dokter', 'N'),
('12345', '827ccb0eea8a706c4c34a16891f84e7b', 'Jaya Kusuma', 'kosong', '0897887666', 'pasien', 'N');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
